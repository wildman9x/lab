﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Employee_managment
{
    class Employee
    {
        //The employee name
        private string name;
        //The employee ID number
        private string idNumber;
        //The employee birth year
        private int birthYear;
        //The employee address
        private string address;
        //The employee phone number
        private string phoneNumber;
        //The employee department
        private string department;
        //The employee salary
        private int salary;
        //The employee title
        private string title;

        // initialize the employee
        public Employee(){
            name = "";
            idNumber = "";
            birthYear = 0;
            address = "";
            phoneNumber = "";
            department = "";
            salary = 0;
            title = "";
        }
        //The constructor of the employee
        public Employee(string name, 
        string idNumber, string title, 
        int birthYear, string address, 
        string phoneNumber, string department, int salary)
        {
            this.name = name;
            this.idNumber = idNumber;
            this.birthYear = birthYear;
            this.address = address;
            this.phoneNumber = phoneNumber;
            this.department = department;
            this.salary = salary;
            this.title = title;

        }
        //print the employee information with tab
        public void PrintEmployee()
        {
            Console.WriteLine("{0}\t{1}\t{2}\t{3}\t{4}\t{5}\t{6}\t{7}", "Name", "ID", "Title", "BirthYear", 
            "Address", "Phone", "Department", "Salary");
            Console.WriteLine("{0}\t{1}\t{2}\t{3}\t{4}\t{5}\t{6}\t{7}", name, idNumber, title, birthYear,
             address, phoneNumber, department, salary);
        }

        //ToString method
        public override string ToString()
        {
            return "Name: " + name + " ID: " + idNumber + " Title: " + title + 
            " Birth year: " + birthYear + " Address: " + address + 
            " Phone number: " + phoneNumber + " Department: " + department + 
            " Salary: " + salary;
        }

        //Getters and setters
        public string Name { get => name; set => name = value; }
        public string IdNumber { get => idNumber; set => idNumber = value; }
        public int BirthYear { get => birthYear; set => birthYear = value; }
        public string Address { get => address; set => address = value; }
        public string PhoneNumber { get => phoneNumber; set => phoneNumber = value; }
        public string Department { get => department; set => department = value; }
        public int Salary { get => salary; set => salary = value; }
        public string Title { get => title; set => title = value; }
    }
}

