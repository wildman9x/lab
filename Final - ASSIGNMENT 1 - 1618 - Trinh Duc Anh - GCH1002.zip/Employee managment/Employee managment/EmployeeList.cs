﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Employee_managment
{
    internal class EmployeeList
    {
        //The list of employees
        private List<Employee> employees;

        //The constructor
        public EmployeeList()
        {
            employees = new List<Employee>();
        }

        //Print the list of employees with all information in tab format
        public void Print()
        {
            Console.WriteLine("\nEmployee List:");
            Console.WriteLine("{0,-10} {1,-10} {2,-10} {3,-10} {4,-10} {5,-10}", "Name", "Birth Year", 
            "ID", "Department", "Salary", "Position");
            foreach (Employee employee in employees)
            {
                Console.WriteLine("{0,-10} {1,-10} {2,-10} {3,-10} {4,-10} {5,-10}", employee.Name,
                 employee.BirthYear, employee.IdNumber, employee.Department, employee.Salary, employee.Title);
            }
        }

        //Add an employee to the list
        public void AddEmployee(Employee employee)
        {
            employees.Add(employee);
        }

        //Remove an employee from the list
        public void RemoveEmployee(Employee employee)
        {
            employees.Remove(employee);
        }

        //remove an employee from the list by id
        public void RemoveEmployeeById(string id)
        {
            employees.Remove(employees.Find(x => x.IdNumber == id));
        }

        //Get the list of employees
        public List<Employee> GetEmployees()
        {
            return employees;
        }

        //get employee by id
        public Employee GetEmployeeById(string id)
        {
            foreach (Employee employee in employees)
            {
                if (employee.IdNumber == id)
                {
                    return employee;
                }
            }
            return null;
        }

        //Search for an employee by id
        public Employee SearchEmployeeById(string id)
        {
            foreach (Employee employee in employees)
            {
                if (employee.IdNumber.ToLower().Contains(id.ToLower()))
                {
                    return employee;
                }
            }
            return null;
        }
        public Employee SearchEmployeeByName(string name)
        {
            foreach (Employee employee in employees)
            {
                if (employee.Name.ToLower().Contains(name.ToLower()))
                {
                    return employee;
                }
            }
            return null;
        }

        //remove employee by index
        public void RemoveEmployeeByIndex(int index)
        {
            employees.RemoveAt(index);
        }

        //edit employee information by index
        public void EditEmployeeByIndex(int index, Employee employee)
        {
            employees[index] = employee;
        }

        //Search for an employee by name using contain
        
        //Get the number of employees
        public int GetNumberOfEmployees()
        {
            return employees.Count;
        }

        //Get all tilte
        public List<string> GetAllTitle()
        {
            List<string> titles = new List<string>();
            foreach (Employee employee in employees)
            {
                titles.Add(employee.Title);
            }
            return titles;
        }
        //Get the total salary of all employees
        public double GetTotalSalary()
        {
            double totalSalary = 0;
            foreach (Employee employee in employees)
            {
                totalSalary += employee.Salary;
            }
            return totalSalary;
        }

        //Get the average salary of all employees
        public double GetAverageSalary()
        {
            return GetTotalSalary() / GetNumberOfEmployees();
        }

        //get employee by index
        public Employee GetEmployeeByIndex(int index)
        {
            return employees[index];
        }

        //Get the total salary of all employees with a given title
        public double GetTotalSalaryByTitle(string title)
        {
            double totalSalary = 0;
            foreach (Employee employee in employees)
            {
                if (employee.Title == title)
                {
                    totalSalary += employee.Salary;
                }
            }
            return totalSalary;
        }
        //Get the average salary of all employees with a given title
        public double GetAverageSalaryByTitle(string title)
        {
            return GetTotalSalaryByTitle(title) / GetNumberOfEmployeesByTitle(title);
        }
        //Get the number of employees with a given title
        public int GetNumberOfEmployeesByTitle(string title)
        {
            int numberOfEmployees = 0;
            foreach (Employee employee in employees)
            {
                if (employee.Title == title)
                {
                    numberOfEmployees++;
                }
            }
            return numberOfEmployees;
        }

    }
}
