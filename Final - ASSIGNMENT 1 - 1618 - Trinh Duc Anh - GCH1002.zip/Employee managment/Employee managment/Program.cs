﻿//The program that help manage the employees
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Employee_managment;

namespace EmployeeManagement
{
    
    class Program
    {
        //check if the id number is duplicate
        static bool IsDuplicateId(List<Employee> employees, string id)
        {
            foreach (Employee employee in employees)
            {
                if (employee.IdNumber == id)
                {
                    return true;
                }
            }
            return false;
        }

        //let the user input the employee information
        static Employee InputEmployee(EmployeeList employees)
        {
            Console.WriteLine("Please enter the employee information:");
            Console.Write("Name: ");
            string name = Console.ReadLine();
            name = Normalize(name);
            Console.Write("ID Number: ");
            string idNumber = Console.ReadLine();
            RemoveExcessiveSpaces(idNumber);
            //check if the id number is duplicate
            while (IsDuplicateId(employees.GetEmployees(), idNumber))
            {
                Console.WriteLine("The ID number is duplicate, please enter again.");
                Console.Write("ID Number: ");
                idNumber = Console.ReadLine();
                RemoveExcessiveSpaces(idNumber);
            }
            Console.Write("Title: ");
            string title = Console.ReadLine();
            title = Normalize(title);
            Console.Write("Birth Year: ");
            //take an integer input and validate it
            int birthYear = 0;
            while (true)
            {
                try
                {
                    birthYear = int.Parse(Console.ReadLine());
                    break;
                }
                catch (Exception)
                {
                    Console.WriteLine("Please enter an integer.");
                }
            }
            Console.Write("Address: ");
            string address = Console.ReadLine();
            address = Normalize(address);
            Console.Write("Phone Number: ");
            string phoneNumber = Console.ReadLine();
            Console.Write("Department: ");
            string department = Console.ReadLine();
            department = Normalize(department);
            Console.Write("Salary: ");
            //take an integer input and validate it
            int salary = 0;
            while (true)
            {
                try
                {
                    salary = int.Parse(Console.ReadLine());
                    break;
                }
                catch (Exception)
                {
                    Console.WriteLine("Please enter an integer.");
                }
            }
            return new Employee(name, idNumber, title, 
            birthYear, address, phoneNumber, department, salary);
        }
        //import a csv file into the employee list
        static void ImportEmployees(EmployeeList employees)
        {
            string filePath = @"C:\Users\wildm\Desktop\Class\Greenwich\1618\c#\Demo1\Employee managment\Employee managment\employees.csv";
            string[] lines = File.ReadAllLines(filePath);
            foreach (string line in lines)
            {
                string[] values = line.Split(',');
                //validate the integer input and set the value to 0 if it is not valid
                int birthYear = 0;
                int salary = 0;
                try
                {
                    birthYear = int.Parse(values[3]);
                }
                catch (Exception)
                {
                    birthYear = 0;
                }
                try
                {
                    salary = int.Parse(values[7]);
                }
                catch (Exception)
                {
                    salary = 0;
                }
                employees.AddEmployee(new Employee(Normalize(values[0]), values[1], Normalize(values[2]), 
                int.Parse(values[3]), Normalize(values[4]), values[5], Normalize(values[6]), 
                int.Parse(values[7])));
            }
        }
        //export the employee list into a csv file
        static void ExportEmployees(EmployeeList employees)
        {
            string filePath = "employees-exported.csv";
            string[] lines = new string[employees.GetNumberOfEmployees()];
            for (int i = 0; i < employees.GetNumberOfEmployees(); i++)
            {
                lines[i] = employees.GetEmployees()[i].Name + "," + employees.GetEmployees()[i].IdNumber + 
                "," + employees.GetEmployees()[i].Title + "," + employees.GetEmployees()[i].BirthYear + 
                "," + employees.GetEmployees()[i].Address + "," + employees.GetEmployees()[i].PhoneNumber + 
                "," + employees.GetEmployees()[i].Department + "," + employees.GetEmployees()[i].Salary;
            }
            File.WriteAllLines(filePath, lines);
        }
        //print all the name of titles in one line and dont print any duplicate
        static void PrintTitles(EmployeeList employees)
        {
            List<string> titles = new List<string>();
            foreach (Employee employee in employees.GetEmployees())
            {
                if (!titles.Contains(employee.Title))
                {
                    titles.Add(employee.Title);
                }
            }
            Console.WriteLine("The titles are: ");
            foreach (string title in titles)
            {
                Console.WriteLine(title);
            }
        }

        //sort the employee by salary in descending order
        static void SortEmployeesBySalary(EmployeeList employees)
        {
            employees.GetEmployees().Sort((x, y) => y.Salary.CompareTo(x.Salary));
        }
        //sort the employee by salary in ascending order
        static void SortEmployeesBySalaryAscending(EmployeeList employees)
        {
            employees.GetEmployees().Sort((x, y) => x.Salary.CompareTo(y.Salary));
        }
        // normalize the name format that uppercase the first letter and lowercase the rest
        static string Normalize(string name)
        {
            name = RemoveExcessiveSpaces(name);
            string[] words = name.Split(' ');
            for (int i = 0; i < words.Length; i++)
            {
                words[i] = words[i].Substring(0, 1).ToUpper() + words[i].Substring(1).ToLower();
            }
            return string.Join(" ", words);
        }
        //remove excessive spaces in the employee name at the start and the end and any replace the excessive spaces with one space
        static string RemoveExcessiveSpaces(string name)
        {
            while (name[0] == ' ')
            {
                name = name.Substring(1);
            }
            while (name[name.Length - 1] == ' ')
            {
                name = name.Substring(0, name.Length - 1);
            }
            while (name.Contains("  "))
            {
                name = name.Replace("  ", " ");
            }
            return name;
        }
        //make the first letter of the name capital
        static string Capitalize(string name)
        {
            string[] words = name.Split(' ');
            string result = "";
            foreach (string word in words)
            {
                result += word.Substring(0, 1).ToUpper() + word.Substring(1) + " ";
            }
            return result.Trim();
        }

                

        static void Main(string[] args)
        {
            //create an employee list
            EmployeeList employeeList = new EmployeeList();
            while (true){
            //create a menu for the program
            Console.WriteLine("Welcome to the Employee Management System");
            Console.WriteLine("1. Add an employee");
            Console.WriteLine("2. Remove an employee");
            Console.WriteLine("3. Print all employees");
            Console.WriteLine("4. Print the total salary");
            Console.WriteLine("5. Print the average salary");
            Console.WriteLine("6. Print the total salary of all employees with a given title");
            Console.WriteLine("7. Print the average salary of all employees with a given title");
            Console.WriteLine("8. Print the number of employees with a given title");
            Console.WriteLine("9. Import employees from a csv file");
            Console.WriteLine("10. Export employees to a csv file");
            Console.WriteLine("11. Sort the employees");
            Console.WriteLine("12. Search for an employee");
            Console.WriteLine("0. Exit");
            Console.WriteLine("Please enter your choice:");
            int choice = Convert.ToInt32(Console.ReadLine());
            switch (choice)
            {
                case 1:
                    Console.Clear();
                    //add an employee
                    Employee employee = InputEmployee(employeeList);
                    employeeList.AddEmployee(employee);
                    Console.WriteLine("Click enter to continue");
                    Console.ReadKey();
                    break;
                case 2:
                    Console.Clear();
                    Console.WriteLine("Please enter the ID number of the employee you want to remove:");
                    string id = Console.ReadLine();
                    Employee employeeToRemove = employeeList.GetEmployeeById(id);
                    employeeList.RemoveEmployee(employeeToRemove);
                    Console.WriteLine("Click enter to continue");
                    Console.ReadKey();
                    break;
                case 3:
                    Console.Clear();
                    employeeList.Print();
                    Console.WriteLine("Click enter to continue");
                    Console.ReadKey();
                    break;
                case 4:
                    Console.Clear();
                    Console.WriteLine("The total salary is {0}", employeeList.GetTotalSalary());
                    Console.WriteLine("Click enter to continue");
                    Console.ReadKey();
                    break;
                case 5:
                    Console.Clear();
                    Console.WriteLine("The average salary is {0}", employeeList.GetAverageSalary());
                    Console.WriteLine("Click enter to continue");
                    Console.ReadKey();
                    break;
                case 6:
                    Console.Clear();
                    Console.WriteLine("Please enter the title:");
                    //print all title
                    PrintTitles(employeeList);
                    string title1 = Console.ReadLine();
                    Console.WriteLine("The total salary is {0}", employeeList.GetTotalSalaryByTitle(title1));
                    Console.WriteLine("Click enter to continue");
                    Console.ReadKey();
                    break;
                case 7:
                    Console.Clear();
                    Console.WriteLine("Please enter the title:");
                    PrintTitles(employeeList);
                    string title2 = Console.ReadLine();
                    Console.WriteLine("The average salary is {0}", employeeList.GetAverageSalaryByTitle(title2));
                    Console.WriteLine("Click enter to continue");
                    Console.ReadKey();
                    break;
                case 8:
                    Console.Clear();
                    Console.WriteLine("Please enter the title:");
                    PrintTitles(employeeList);
                    string title3 = Console.ReadLine();
                    Console.WriteLine("The number of employees with the title {0} is {1}", title3, employeeList.GetNumberOfEmployeesByTitle(title3));
                    Console.WriteLine("Click enter to continue");
                    Console.ReadKey();
                    break;
                case 9:
                    Console.Clear();
                    ImportEmployees(employeeList);
                    Console.WriteLine("Click enter to continue");
                    Console.ReadKey();
                    break;
                case 10:
                    Console.Clear();
                    ExportEmployees(employeeList);
                    Console.WriteLine("Click enter to continue");
                    Console.ReadKey();
                    break;
                case 11:
                    Console.Clear();
                    Console.WriteLine("Please enter the order you want to sort the employees by:");
                    Console.WriteLine("1. Sort by salary in descending order");
                    Console.WriteLine("2. Sort by salary in ascending order");
                    int order = Convert.ToInt32(Console.ReadLine());
                    switch (order)
                    {
                        case 1:
                            SortEmployeesBySalary(employeeList);
                            break;
                        case 2:
                            SortEmployeesBySalaryAscending(employeeList);
                            break;
                        default:
                            Console.WriteLine("Invalid input");
                            break;
                    }
                    Console.WriteLine("Sort completed");
                    Console.WriteLine("Click enter to continue");
                    Console.ReadKey();
                    break;
                case 12:
                    Console.Clear();
                    Console.WriteLine("Please choose the search method:");
                    Console.WriteLine("1. Search by ID");
                    Console.WriteLine("2. Search by name");
                    int searchMethod = Convert.ToInt32(Console.ReadLine());
                    switch (searchMethod)
                    {
                        case 1:
                            Console.WriteLine("Please enter the ID number of the employee you want to search:");
                            string idToSearch = Console.ReadLine();
                            Employee employeeToSearch = employeeList.SearchEmployeeById(idToSearch);
                            if (employeeToSearch != null)
                            {
                                Console.WriteLine("The employee with the ID {0} is {1}", idToSearch, employeeToSearch.ToString());
                            }
                            else
                            {
                                Console.WriteLine("No employee with the ID {0}", idToSearch);
                            }
                            break;
                        case 2:
                            Console.WriteLine("Please enter the name of the employee you want to search:");
                            string nameToSearch = Console.ReadLine();
                            Employee employeeToSearch2 = employeeList.SearchEmployeeByName(nameToSearch);
                            if (employeeToSearch2 != null)
                            {
                                Console.WriteLine("The employee with the name {0} is {1}", nameToSearch, employeeToSearch2.ToString());
                            }
                            else
                            {
                                Console.WriteLine("No employee with the name {0}", nameToSearch);
                            }
                            break;
                        default:
                            Console.WriteLine("Invalid input");
                            break;
                    }
                    Console.WriteLine("Click enter to continue");
                    Console.ReadKey();
                    break;
                case 0:
                    Environment.Exit(0);
                    Console.ReadKey();
                    break;
                default:
                    Console.WriteLine("Invalid input");
                    Console.WriteLine("Please enter a valid choice");
                    Console.ReadKey();
                    break;
            }
            }

        }
    }
}